export default {
  QQ_APP_ID: "102009697",
  QQ_REDIRECT_URI: "http://www.lxuan.fun/oauth/login/qq",
  WEIBO_APP_ID: "2048874845",
  WEIBO_REDIRECT_URI: "http://www.lxuan.fun/oauth/login/weibo",
  TENCENT_CAPTCHA: "2088053498"
};
